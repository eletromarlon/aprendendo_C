# Graph implementation in C code

Basic implementation of a Graph representation of an adjacency list with a linked list for the nodes.
Floyd Warshall Algorithm implemented to calculate the routes.
